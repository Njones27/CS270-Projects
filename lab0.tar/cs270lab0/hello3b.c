#include <stdio.h>

int main(void) {
      char whomtogreet[6] = "world";
      printf("Hello, %p!\n",whomtogreet);
      return 0;
    }
