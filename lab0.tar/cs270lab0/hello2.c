#include <stdio.h>

int main(void)
{
	printf("Hello, %s!\n", "world");
	return 0;
}
