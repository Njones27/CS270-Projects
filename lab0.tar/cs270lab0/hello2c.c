#include <stdio.h>

int main(void) {
      char *whomtogreet = "world";
      printf("Hello, %s!\n", whomtogreet);
      return 0;
    }
