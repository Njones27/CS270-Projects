#include <stdio.h>

int main(void) {
      char *whomtogreet = "world";
      printf("Hello, %p!\n", whomtogreet);
      return 0;
    }
