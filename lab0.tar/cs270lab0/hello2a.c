#include <stdio.h>

int main(void) {
      char whomtogreet[6] = {'w','o','r','l','d', 0};
      printf("Hello, %s!\n",whomtogreet);
      return 0;
    }
